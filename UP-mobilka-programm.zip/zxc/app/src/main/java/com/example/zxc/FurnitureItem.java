package com.example.zxc;

public class FurnitureItem {
    String name;
    String brand;
    int price;
    int quantity;
    int imageResId;
    String description;
    String reviews;

    public FurnitureItem(String name,
                         String brand,
                         int price,
                         int quantity,
                         int imageResId,
                         String description,
                         String reviews) {
        this.name = name;
        this.brand = brand;
        this.price = price;
        this.quantity = quantity;
        this.imageResId = imageResId;
        this.description = description;
        this.reviews = reviews;
    }
}
