package com.example.zxc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class CartActivity extends AppCompatActivity {

    ListView listViewCart;
    TextView textViewTotal, textViewCartTitle;
    Button buttonClearCart, buttonConfirmOrder;

    RadioGroup radioGroupPayment;
    RadioButton radioPaymentCash, radioPaymentCard;

    RadioGroup radioGroupDeliveryType;
    RadioButton radioPickup, radioDelivery;

    LinearLayout layoutPickup, layoutDelivery;
    Spinner spinnerPickupPoint, spinnerTime;
    EditText editTextAddress;

    String userLogin;
    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        listViewCart = findViewById(R.id.listViewCart);
        textViewTotal = findViewById(R.id.textViewTotal);
        textViewCartTitle = findViewById(R.id.textViewCartTitle);
        buttonClearCart = findViewById(R.id.buttonClearCart);
        buttonConfirmOrder = findViewById(R.id.buttonConfirmOrder);

        radioGroupPayment = findViewById(R.id.radioGroupPayment);
        radioPaymentCash = findViewById(R.id.radioPaymentCash);
        radioPaymentCard = findViewById(R.id.radioPaymentCard);

        radioGroupDeliveryType = findViewById(R.id.radioGroupDeliveryType);
        radioPickup = findViewById(R.id.radioPickup);
        radioDelivery = findViewById(R.id.radioDelivery);

        layoutPickup = findViewById(R.id.layoutPickup);
        layoutDelivery = findViewById(R.id.layoutDelivery);
        spinnerPickupPoint = findViewById(R.id.spinnerPickupPoint);
        spinnerTime = findViewById(R.id.spinnerTime);
        editTextAddress = findViewById(R.id.editTextAddress);


        userLogin = getIntent().getStringExtra("login");
        if (userLogin == null || userLogin.isEmpty()) {
            userLogin = "гость";
        }

        dbHelper = new DBHelper(this);


        List<FurnitureItem> cartItems = CartManager.getCartItems();
        FurnitureAdapter adapter = new FurnitureAdapter(this, cartItems);
        listViewCart.setAdapter(adapter);


        String[] pickupPoints = new String[] {
                "Склад №1: ул. Лесная, 10",
                "Склад №2: пр-т Мира, 25",
                "Магазин: ул. Центральная, 5"
        };
        ArrayAdapter<String> pickupAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                pickupPoints
        );
        pickupAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerPickupPoint.setAdapter(pickupAdapter);


        String[] timeSlots = new String[] {
                "с 10:00 до 12:00",
                "с 12:00 до 14:00",
                "с 14:00 до 16:00",
                "с 16:00 до 18:00",
                "с 18:00 до 20:00",
                "с 20:00 до 22:00"
        };
        ArrayAdapter<String> timeAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                timeSlots
        );
        timeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerTime.setAdapter(timeAdapter);

        updateTotal();


        buttonClearCart.setOnClickListener(v -> {
            CartManager.clearCart();
            adapter.notifyDataSetChanged();
            updateTotal();
            Toast.makeText(this, "Корзина очищена", Toast.LENGTH_SHORT).show();
        });


        radioGroupDeliveryType.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.radioPickup) {
                layoutPickup.setVisibility(View.VISIBLE);
                layoutDelivery.setVisibility(View.GONE);
            } else if (checkedId == R.id.radioDelivery) {
                layoutPickup.setVisibility(View.GONE);
                layoutDelivery.setVisibility(View.VISIBLE);
            }
        });


        buttonConfirmOrder.setOnClickListener(v -> confirmOrder());
    }

    private void updateTotal() {
        int total = CartManager.getTotalPrice();
        textViewTotal.setText("Итого: " + total + " руб.");
    }

    private void confirmOrder() {
        int paymentId = radioGroupPayment.getCheckedRadioButtonId();
        int deliveryId = radioGroupDeliveryType.getCheckedRadioButtonId();

        if (CartManager.getCartItems().isEmpty()) {
            Toast.makeText(this, "Корзина пуста", Toast.LENGTH_SHORT).show();
            return;
        }

        if (paymentId == -1) {
            Toast.makeText(this, "Выберите способ оплаты", Toast.LENGTH_SHORT).show();
            return;
        }

        if (deliveryId == -1) {
            Toast.makeText(this, "Выберите способ получения", Toast.LENGTH_SHORT).show();
            return;
        }

        String paymentType = (paymentId == R.id.radioPaymentCash)
                ? "оплата при получении"
                : "оплата картой";

        String deliveryInfo;

        if (deliveryId == R.id.radioPickup) {
            String pickupPoint = spinnerPickupPoint.getSelectedItem().toString();
            deliveryInfo = "самовывоз из: " + pickupPoint;
        } else {
            String address = editTextAddress.getText().toString().trim();
            String time = spinnerTime.getSelectedItem().toString();

            if (address.isEmpty()) {
                Toast.makeText(this,
                        "Укажите адрес доставки",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            deliveryInfo = "доставка по адресу: " + address + ", время: " + time;
        }

        int total = CartManager.getTotalPrice();
        String dateText = java.text.DateFormat
                .getDateTimeInstance()
                .format(new java.util.Date());


        dbHelper.addOrder(userLogin, total, deliveryInfo, dateText);

        String message = "Заказ оформлен, " + paymentType + ", " + deliveryInfo;
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();

        CartManager.clearCart();
        ((FurnitureAdapter) listViewCart.getAdapter()).notifyDataSetChanged();
        updateTotal();
    }
}
