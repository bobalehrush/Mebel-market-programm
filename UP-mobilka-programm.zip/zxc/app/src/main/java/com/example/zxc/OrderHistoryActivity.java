package com.example.zxc;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class OrderHistoryActivity extends AppCompatActivity {

    TextView textViewHistoryTitle;
    ListView listViewHistory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_history);

        textViewHistoryTitle = findViewById(R.id.textViewHistoryTitle);
        listViewHistory = findViewById(R.id.listViewHistory);

        String login = getIntent().getStringExtra("login");
        if (login == null || login.isEmpty()) {
            login = "гость";
        }

        textViewHistoryTitle.setText("История покупок: " + login);

        DBHelper dbHelper = new DBHelper(this);
        Cursor cursor = dbHelper.getOrdersForUser(login);

        ArrayList<String> items = new ArrayList<>();

        if (cursor != null && cursor.moveToFirst()) {
            int idxSum = cursor.getColumnIndex(DBHelper.COLUMN_ORDER_SUM);
            int idxInfo = cursor.getColumnIndex(DBHelper.COLUMN_ORDER_INFO);
            int idxDate = cursor.getColumnIndex(DBHelper.COLUMN_ORDER_DATE);

            do {
                int sum = cursor.getInt(idxSum);
                String info = cursor.getString(idxInfo);
                String date = cursor.getString(idxDate);

                String line = date + " | " + sum + " руб. | " + info;
                items.add(line);
            } while (cursor.moveToNext());

            cursor.close();
        } else {
            Toast.makeText(this, "История покупок пуста", Toast.LENGTH_SHORT).show();
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                items
        );
        listViewHistory.setAdapter(adapter);
    }
}
