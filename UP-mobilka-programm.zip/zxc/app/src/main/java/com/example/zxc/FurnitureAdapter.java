package com.example.zxc;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class FurnitureAdapter extends ArrayAdapter<FurnitureItem> {

    public FurnitureAdapter(@NonNull Context context, @NonNull List<FurnitureItem> objects) {
        super(context, 0, objects);
    }

    @NonNull
    @Override
    public View getView(int position,
                        @Nullable View convertView,
                        @NonNull ViewGroup parent) {

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext())
                    .inflate(R.layout.item_furniture, parent, false);
        }

        FurnitureItem item = getItem(position);

        ImageView imageView = convertView.findViewById(R.id.imageViewItem);
        TextView textName = convertView.findViewById(R.id.textViewName);
        TextView textBrand = convertView.findViewById(R.id.textViewBrand);
        TextView textPrice = convertView.findViewById(R.id.textViewPrice);

        if (item != null) {
            if (item.imageResId != 0) {
                imageView.setImageResource(item.imageResId);
            }
            textName.setText(item.name);
            textBrand.setText("Марка: " + item.brand);
            textPrice.setText("Цена: " + item.price + " руб.");
        }

        return convertView;
    }
}
