package com.example.zxc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class WelcomeActivity extends AppCompatActivity {

    TextView textViewWelcomeTitle, textViewWelcomeMessage;
    Button buttonGoToCatalog, buttonOrderHistory;

    String login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        textViewWelcomeTitle = findViewById(R.id.textViewWelcomeTitle);
        textViewWelcomeMessage = findViewById(R.id.textViewWelcomeMessage);
        buttonGoToCatalog = findViewById(R.id.buttonGoToCatalog);
        buttonOrderHistory = findViewById(R.id.buttonOrderHistory);

        login = getIntent().getStringExtra("login");
        if (login != null && !login.isEmpty()) {
            textViewWelcomeTitle.setText("Рады снова вас видеть, " + login + "!");
        }

        buttonGoToCatalog.setOnClickListener(v -> {
            Intent intent = new Intent(WelcomeActivity.this, HomeActivity.class);
            intent.putExtra("login", login);
            startActivity(intent);
            finish();
        });

        buttonOrderHistory.setOnClickListener(v -> {
            Intent intent = new Intent(WelcomeActivity.this, OrderHistoryActivity.class);
            intent.putExtra("login", login);
            startActivity(intent);
        });
    }
}
