package com.example.zxc;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "users.db";
    private static final int DB_VERSION = 2; // увеличили версию для новой таблицы


    public static final String TABLE_USERS = "users";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_LOGIN = "login";
    public static final String COLUMN_PASSWORD = "password";

    
    public static final String TABLE_ORDERS = "orders";
    public static final String COLUMN_ORDER_ID = "_id";
    public static final String COLUMN_ORDER_USER_LOGIN = "user_login";
    public static final String COLUMN_ORDER_SUM = "total_sum";
    public static final String COLUMN_ORDER_INFO = "info";
    public static final String COLUMN_ORDER_DATE = "order_date";

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsers = "CREATE TABLE " + TABLE_USERS + " ("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_LOGIN + " TEXT UNIQUE, "
                + COLUMN_PASSWORD + " TEXT"
                + ");";

        String createOrders = "CREATE TABLE " + TABLE_ORDERS + " ("
                + COLUMN_ORDER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_ORDER_USER_LOGIN + " TEXT, "
                + COLUMN_ORDER_SUM + " INTEGER, "
                + COLUMN_ORDER_INFO + " TEXT, "
                + COLUMN_ORDER_DATE + " TEXT"
                + ");";

        db.execSQL(createUsers);
        db.execSQL(createOrders);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Простой вариант: пересоздать таблицы (для учебного проекта норм)
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ORDERS);
        onCreate(db);
    }



    public boolean addUser(String login, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_LOGIN, login);
        values.put(COLUMN_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        db.close();

        return result != -1;
    }

    public boolean checkUser(String login, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        String[] columns = { COLUMN_ID };
        String selection = COLUMN_LOGIN + " = ? AND " + COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = { login, password };

        Cursor cursor = db.query(TABLE_USERS,
                columns,
                selection,
                selectionArgs,
                null,
                null,
                null);

        boolean exists = cursor.moveToFirst();
        cursor.close();
        db.close();

        return exists;
    }


    public boolean addOrder(String userLogin, int totalSum, String info, String date) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_ORDER_USER_LOGIN, userLogin);
        values.put(COLUMN_ORDER_SUM, totalSum);
        values.put(COLUMN_ORDER_INFO, info);
        values.put(COLUMN_ORDER_DATE, date);

        long result = db.insert(TABLE_ORDERS, null, values);
        db.close();

        return result != -1;
    }


    public Cursor getOrdersForUser(String userLogin) {
        SQLiteDatabase db = this.getReadableDatabase();

        String[] columns = {
                COLUMN_ORDER_ID,
                COLUMN_ORDER_SUM,
                COLUMN_ORDER_INFO,
                COLUMN_ORDER_DATE
        };
        String selection = COLUMN_ORDER_USER_LOGIN + " = ?";
        String[] selectionArgs = { userLogin };


        return db.query(TABLE_ORDERS,
                columns,
                selection,
                selectionArgs,
                null,
                null,
                COLUMN_ORDER_ID + " DESC");
    }
}
