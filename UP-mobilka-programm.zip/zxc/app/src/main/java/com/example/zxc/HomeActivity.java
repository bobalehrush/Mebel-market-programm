package com.example.zxc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

    TextView textViewWelcome;
    ListView listViewCatalog;
    Button buttonCart;

    String login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        textViewWelcome = findViewById(R.id.textViewWelcome);
        listViewCatalog = findViewById(R.id.listViewCatalog);
        buttonCart = findViewById(R.id.buttonCart);

        login = getIntent().getStringExtra("login");

        List<FurnitureItem> items = new ArrayList<>();

        items.add(new FurnitureItem(
                "Диван угловой «Комфорт»",
                "MebelPlus",
                35000,
                5,
                R.drawable.sofa_ugol,
                "Угловой диван для гостиной, обивка из износостойкой ткани.",
                "Покупатели отмечают удобство и мягкость, подходит для ежедневного использования."
        ));

        items.add(new FurnitureItem(
                "Кресло «Релакс»",
                "SoftLine",
                15000,
                8,
                R.drawable.kreslo,
                "Кресло с высокой спинкой и подлокотниками для отдыха.",
                "Часто хвалят за удобство посадки и мягкую обивку."
        ));

        items.add(new FurnitureItem(
                "Стол обеденный «Классик»",
                "WoodArt",
                12000,
                3,
                R.drawable.stol,
                "Деревянный обеденный стол на 4–6 человек.",
                "Отмечают прочную конструкцию и простой дизайн."
        ));

        items.add(new FurnitureItem(
                "Стул деревянный «Лайт»",
                "WoodArt",
                3500,
                20,
                R.drawable.styl,
                "Лёгкий деревянный стул с мягким сиденьем.",
                "Хвалят за компактность и удобство."
        ));

        items.add(new FurnitureItem(
                "Шкаф-купе «Практик»",
                "DomMebel",
                28000,
                2,
                R.drawable.skaf,
                "Шкаф-купе с зеркальными дверями для спальни или прихожей.",
                "Пишут, что удобно хранить одежду и обувь."
        ));

        items.add(new FurnitureItem(
                "Кровать двуспальная «Соната»",
                "SleepWell",
                32000,
                4,
                R.drawable.bed,
                "Двуспальная кровать с ортопедическим основанием.",
                "Отмечают удобный сон и надёжную конструкцию."
        ));

        items.add(new FurnitureItem(
                "Тумба прикроватная «Мини»",
                "MebelPlus",
                4500,
                10,
                R.drawable.tumba,
                "Небольшая тумба с выдвижным ящиком.",
                "Подходит для хранения мелочей рядом с кроватью."
        ));

        FurnitureAdapter adapter = new FurnitureAdapter(this, items);
        listViewCatalog.setAdapter(adapter);

        buttonCart.setOnClickListener(v -> {
            Intent intent = new Intent(HomeActivity.this, CartActivity.class);
            intent.putExtra("login", login);
            startActivity(intent);
        });

        listViewCatalog.setOnItemClickListener((parent, view, position, id) -> {
            FurnitureItem item = items.get(position);

            Intent intent = new Intent(HomeActivity.this, ProductDetailActivity.class);
            intent.putExtra("name", item.name);
            intent.putExtra("brand", item.brand);
            intent.putExtra("price", item.price);
            intent.putExtra("quantity", item.quantity);
            intent.putExtra("imageResId", item.imageResId);
            intent.putExtra("description", item.description);
            intent.putExtra("reviews", item.reviews);

            startActivity(intent);
        });
    }
}
