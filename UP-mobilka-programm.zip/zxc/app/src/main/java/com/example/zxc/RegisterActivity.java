package com.example.zxc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    EditText editTextNewLogin, editTextNewPassword;
    Button buttonRegisterUser;

    DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        editTextNewLogin = findViewById(R.id.editTextNewLogin);
        editTextNewPassword = findViewById(R.id.editTextNewPassword);
        buttonRegisterUser = findViewById(R.id.buttonRegisterUser);

        dbHelper = new DBHelper(this);

        buttonRegisterUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String newLogin = editTextNewLogin.getText().toString().trim();
                String newPassword = editTextNewPassword.getText().toString().trim();

                if (newLogin.isEmpty() || newPassword.isEmpty()) {
                    Toast.makeText(RegisterActivity.this,
                            "Введите логин и пароль",
                            Toast.LENGTH_SHORT).show();
                } else {
                    boolean success = dbHelper.addUser(newLogin, newPassword);
                    if (success) {
                        Toast.makeText(RegisterActivity.this,
                                "Регистрация прошла успешно",
                                Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(RegisterActivity.this,
                                "Такой логин уже существует",
                                Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
