package com.example.zxc;

import java.util.ArrayList;
import java.util.List;

public class CartManager {

    private static final List<FurnitureItem> cartItems = new ArrayList<>();

    public static void addToCart(FurnitureItem item) {
        cartItems.add(item);
    }

    public static List<FurnitureItem> getCartItems() {
        return cartItems;
    }

    public static int getTotalPrice() {
        int sum = 0;
        for (FurnitureItem item : cartItems) {
            sum += item.price;
        }
        return sum;
    }

    public static void clearCart() {
        cartItems.clear();
    }
}
