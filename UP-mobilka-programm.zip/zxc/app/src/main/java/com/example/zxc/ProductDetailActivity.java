package com.example.zxc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class ProductDetailActivity extends AppCompatActivity {

    ImageView imageViewProduct;
    TextView textViewProductName, textViewProductBrand, textViewProductPrice,
            textViewProductQuantity, textViewProductDescription, textViewProductReviews;
    Button buttonBuyNow, buttonBuyInInstallments;

    FurnitureItem currentItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);

        imageViewProduct = findViewById(R.id.imageViewProduct);
        textViewProductName = findViewById(R.id.textViewProductName);
        textViewProductBrand = findViewById(R.id.textViewProductBrand);
        textViewProductPrice = findViewById(R.id.textViewProductPrice);
        textViewProductQuantity = findViewById(R.id.textViewProductQuantity);
        textViewProductDescription = findViewById(R.id.textViewProductDescription);
        textViewProductReviews = findViewById(R.id.textViewProductReviews);
        buttonBuyNow = findViewById(R.id.buttonBuyNow);
        buttonBuyInInstallments = findViewById(R.id.buttonBuyInInstallments);

        String name = getIntent().getStringExtra("name");
        String brand = getIntent().getStringExtra("brand");
        int price = getIntent().getIntExtra("price", 0);
        int quantity = getIntent().getIntExtra("quantity", 0);
        int imageResId = getIntent().getIntExtra("imageResId", 0);
        String description = getIntent().getStringExtra("description");
        String reviews = getIntent().getStringExtra("reviews");

        currentItem = new FurnitureItem(
                name,
                brand,
                price,
                quantity,
                imageResId,
                description,
                reviews
        );

        if (imageResId != 0) {
            imageViewProduct.setImageResource(imageResId);
        }

        textViewProductName.setText(name);
        textViewProductBrand.setText("Марка: " + brand);
        textViewProductPrice.setText("Цена: " + price + " руб.");
        textViewProductQuantity.setText("В наличии: " + quantity + " шт.");
        textViewProductDescription.setText("Описание: " + description);
        textViewProductReviews.setText("Отзывы: " + reviews);

        buttonBuyNow.setOnClickListener(view -> {
            CartManager.addToCart(currentItem);
            Toast.makeText(ProductDetailActivity.this,
                    "Товар добавлен в корзину",
                    Toast.LENGTH_SHORT).show();
        });

        buttonBuyInInstallments.setOnClickListener(view -> {
            CartManager.addToCart(currentItem);
            Toast.makeText(ProductDetailActivity.this,
                    "Товар добавлен в корзину (рассрочка — заглушка)",
                    Toast.LENGTH_SHORT).show();
        });
    }
}
